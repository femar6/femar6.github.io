<?php
$windowsUser = $_SERVER['AUTH_USER'] ?? $_SERVER['REMOTE_USER'] ?? '';
$email = '';
$requesterName = '';
$readonly = '';

if (!empty($windowsUser)) {
    $parts = explode("\\", $windowsUser);
    $username = end($parts);

    $email = strtolower($username) . "@fema.dhs.gov";
    $requesterName = ucwords(str_replace(".", " ", strtolower($username)));
    $readonly = 'readonly';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DAT Request Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h1>DATA ANALYSIS TEAM (DAT) Request Form</h1>
    <p class="subtitle">Submit GIS, mapping, dashboard, spatial data, or analysis requests.</p>

    <form action="submit.php" method="POST">

        <label>Requester Name *</label>
        <input 
            type="text" 
            name="requester_name" 
            value="<?php echo htmlspecialchars($requesterName); ?>"
            placeholder="First Last"
            <?php echo $readonly; ?>
            required>

        <label>Email *</label>
        <input 
            type="email" 
            name="email" 
            id="email"
            value="<?php echo htmlspecialchars($email); ?>"
            placeholder="username@fema.dhs.gov"
            pattern="^[a-zA-Z0-9._%+-]+@fema\.dhs\.gov$"
            title="Must be a FEMA email address"
            <?php echo $readonly; ?>
            required>

        <small>If your email does not auto-fill, enter your FEMA email manually.</small>

        <!-- NEW DROPDOWN -->
        <label>Requesting Office / Program *</label>
        <select name="division" required>
            <option value="">-- Select Office / Program --</option>

            <option>Response</option>
            <option>Recovery</option>
            <option>Mission Support</option>
            <option>Office of the Administrator</option>
            <option>External Affairs</option>

            <optgroup label="Mitigation">
                <option>Mitigation - HMA</option>
                <option>Mitigation - FMI</option>
                <option>Mitigation - RA</option>
                <option>Mitigation - TWIG</option>
            </optgroup>

            <option>National Preparedness</option>
        </select>

        <label>Request Type *</label>
        <select name="request_type" required>
            <option value="">-- Select Request Type --</option>
            <option>Map Creation</option>
            <option>GIS Data Analysis</option>
            <option>Spatial Data Request</option>
            <option>Dashboard / Web Map</option>
            <option>Address Geocoding</option>
            <option>Flood / Risk Analysis</option>
            <option>Report / Visualization</option>
            <option>Data Cleanup / QAQC</option>
            <option>Other</option>
        </select>

        <label>Priority *</label>
        <select name="priority" required>
            <option value="">-- Select Priority --</option>
            <option>Low</option>
            <option>Normal</option>
            <option>High</option>
            <option>Urgent</option>
        </select>

        <label>Requested Due Date</label>
        <input type="date" name="due_date">

        <label>Project Area / Location</label>
        <input 
            type="text" 
            name="location" 
            placeholder="County, city, state, HUC, disaster number, etc.">

        <label>Describe the Request *</label>
        <textarea 
            name="description" 
            rows="7" 
            required></textarea>

        <label>Data Sources / Links</label>
        <textarea 
            name="data_sources" 
            rows="4"></textarea>

        <label>Desired Output</label>
        <select name="output_type">
            <option>Map PDF</option>
            <option>Web Map</option>
            <option>CSV / Excel</option>
            <option>Dashboard</option>
            <option>GIS Layer</option>
            <option>Report</option>
            <option>Other</option>
        </select>

        <button type="submit">Submit DAT Request</button>

    </form>
</div>

<script>
const emailInput = document.getElementById("email");

if (emailInput && !emailInput.readOnly) {
    emailInput.addEventListener("input", function(e) {
        let value = e.target.value;

        if (value.includes("@") && !value.includes("@fema.dhs.gov")) {
            let username = value.split("@")[0];
            e.target.value = username + "@fema.dhs.gov";
        }
    });
}
</script>

</body>
</html>