<?php

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

function clean($value) {
    return trim(str_replace(["\r", "\n"], " ", htmlspecialchars($value)));
}

$request_id = "DAT-" . date("Ymd-His");

$requester_name = clean($_POST["requester_name"] ?? "");
$email          = clean($_POST["email"] ?? "");
$division       = clean($_POST["division"] ?? "");
$request_type   = clean($_POST["request_type"] ?? "");
$priority       = clean($_POST["priority"] ?? "");
$due_date       = clean($_POST["due_date"] ?? "");
$location       = clean($_POST["location"] ?? "");
$description    = clean($_POST["description"] ?? "");
$data_sources   = clean($_POST["data_sources"] ?? "");
$output_type    = clean($_POST["output_type"] ?? "");

$submitted_date = date("Y-m-d");
$status = "New";
$assigned_specialist = "";

$days_left = "";

if (!empty($due_date)) {
    $today = new DateTime($submitted_date);
    $due = new DateTime($due_date);

    $diff = $today->diff($due);
    $days_left = (int)$diff->format("%r%a");
}

if (!preg_match('/^[a-zA-Z0-9._%+-]+@fema\.dhs\.gov$/', $email)) {
    die("Invalid email. Please use a FEMA email address.");
}

$file = "requests.csv";

$row = [
    $request_id,
    $submitted_date,
    $status,
    $assigned_specialist,
    $requester_name,
    $email,
    $division,
    $request_type,
    $priority,
    $due_date,
    $days_left,
    $location,
    $description,
    $data_sources,
    $output_type
];

$file_exists = file_exists($file) && filesize($file) > 0;

$fp = fopen($file, "a");

if (!$fp) {
    die("Unable to write to CSV. Check permissions.");
}

if (!$file_exists) {
    fputcsv($fp, [
        "Request ID",
        "Submitted Date",
        "Status",
        "Assigned Specialist",
        "Requester Name",
        "Email",
        "Office / Program",
        "Request Type",
        "Priority",
        "Due Date",
        "Days Left",
        "Location",
        "Description",
        "Data Sources",
        "Output Type"
    ]);
}

fputcsv($fp, $row);
fclose($fp);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Request Submitted</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container success">
    <h1>Request Submitted</h1>
    <p>Your DAT request has been submitted successfully.</p>

    <div class="request-id">
        Request ID: <strong><?php echo htmlspecialchars($request_id); ?></strong>
    </div>

    <a href="index.php" class="button-link">Submit Another Request</a>
    <a href="dashboard.php" class="button-link">View Dashboard</a>
</div>

</body>
</html>