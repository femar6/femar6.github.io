<?php
require_once "auth.php";

if (!is_logged_in()) {
    die("Unauthorized.");
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: dashboard.php");
    exit;
}

$request_id = $_POST["request_id"] ?? "";
$new_status = $_POST["status"] ?? "";

$allowed_statuses = [
    "New",
    "Assigned",
    "In Progress",
    "Pending Customer",
    "Pending Data",
    "Pending Review",
    "On Hold",
    "Completed",
    "Cancelled",
    "Issue / Blocked"
];

if (!$request_id || !in_array($new_status, $allowed_statuses)) {
    die("Invalid request.");
}

$file = "requests.csv";
$rows = [];

if (($handle = fopen($file, "r")) !== false) {
    while (($row = fgetcsv($handle)) !== false) {
        $rows[] = $row;
    }
    fclose($handle);
}

if (empty($rows)) {
    die("CSV is empty.");
}

$headers = $rows[0];
$statusIndex = array_search("Status", $headers);
$requestIdIndex = array_search("Request ID", $headers);

if ($statusIndex === false || $requestIdIndex === false) {
    die("Required CSV columns missing.");
}

for ($i = 1; $i < count($rows); $i++) {
    if (($rows[$i][$requestIdIndex] ?? "") === $request_id) {
        $rows[$i][$statusIndex] = $new_status;
        break;
    }
}

if (($handle = fopen($file, "w")) !== false) {
    foreach ($rows as $row) {
        fputcsv($handle, $row);
    }
    fclose($handle);
}

header("Location: dashboard.php");
exit;