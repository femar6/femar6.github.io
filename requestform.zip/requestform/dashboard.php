<?php
require_once "auth.php";

$isLoggedIn = is_logged_in();

$file = "requests.csv";
$requests = [];

$expectedHeaders = [
    "Request ID",
    "Submitted Date",
    "Status",
    "Assigned Specialist",
    "Requester Name",
    "Email",
    "Office / Program",
    "Request Type",
    "Priority",
    "Due Date",
    "Days Left",
    "Location",
    "Description",
    "Data Sources",
    "Output Type"
];

if (file_exists($file)) {
    $handle = fopen($file, "r");

    if ($handle !== false) {
        $headers = null;

        while (($row = fgetcsv($handle)) !== false) {
            if (count($row) === 0 || (count($row) === 1 && trim($row[0]) === "")) {
                continue;
            }

            if ($headers === null) {
                if (($row[0] ?? "") === "Request ID") {
                    $headers = $row;

                    if (!in_array("Assigned Specialist", $headers)) {
                        $statusIndex = array_search("Status", $headers);
                        array_splice($headers, $statusIndex + 1, 0, "Assigned Specialist");
                    }

                    continue;
                } else {
                    $headers = $expectedHeaders;
                }
            }

            if (count($row) === count($headers) - 1 && in_array("Assigned Specialist", $headers)) {
                $statusIndex = array_search("Status", $headers);
                array_splice($row, $statusIndex + 1, 0, "");
            }

            if (count($row) === count($headers)) {
                $requests[] = array_combine($headers, $row);
            }
        }

        fclose($handle);
    }
}

$requestsJson = json_encode($requests);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Analytics Team (DAT) Request Dashboard</title>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.9.0/d3.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>

    <style>
        :root {
            --blue: #174a7c;
            --cyan: #37b6ff;
            --green: #28a745;
            --yellow: #ffc107;
            --red: #dc3545;
            --purple: #7b61ff;
            --card: rgba(255,255,255,0.94);
            --text: #1d2630;
            --muted: #667085;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(55,182,255,0.25), transparent 35%),
                linear-gradient(135deg, #e8f1fa 0%, #f7f9fc 45%, #eef3f8 100%);
            color: var(--text);
        }

        .hero {
            background: linear-gradient(135deg, #07192b 0%, #123c63 50%, #0d2238 100%);
            color: white;
            padding: 34px 42px 90px;
            position: relative;
            overflow: hidden;
        }

        .hero::after {
            content: "";
            position: absolute;
            right: -120px;
            top: -120px;
            width: 420px;
            height: 420px;
            background: radial-gradient(circle, rgba(55,182,255,0.35), transparent 65%);
            border-radius: 50%;
        }

        .hero h1 {
            margin: 0;
            font-size: 36px;
        }

        .hero p {
            margin: 8px 0 0;
            color: #d8e7f5;
            font-size: 16px;
        }

        .dashboard {
            max-width: 1500px;
            margin: -58px auto 40px;
            padding: 0 28px;
            position: relative;
            z-index: 2;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            align-items: center;
            margin-bottom: 20px;
        }

        .filters {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            background: var(--card);
            padding: 16px;
            border-radius: 18px;
            box-shadow: 0 14px 35px rgba(15, 35, 55, 0.12);
        }

        select,
        input {
            padding: 11px 13px;
            border-radius: 12px;
            border: 1px solid #d0d7de;
            min-width: 190px;
            font-size: 14px;
            background: white;
        }

        .btn {
            background: var(--blue);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 11px 16px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 600;
        }

        .btn:hover { background: #0f3459; }

        .kpis {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 18px;
            margin-bottom: 22px;
        }

        .card {
            background: var(--card);
            border-radius: 22px;
            padding: 20px;
            box-shadow: 0 14px 35px rgba(15, 35, 55, 0.12);
            border: 1px solid rgba(255,255,255,0.75);
        }

        .kpi-label {
            color: var(--muted);
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.8px;
        }

        .kpi-value {
            margin-top: 8px;
            font-size: 34px;
            font-weight: 800;
        }

        .kpi-note {
            margin-top: 6px;
            font-size: 13px;
            color: var(--muted);
        }

        .grid {
            display: grid;
            grid-template-columns: 1.2fr 1fr 1fr;
            gap: 18px;
            margin-bottom: 22px;
        }

        .wide { grid-column: span 2; }

        .card h2 {
            margin: 0 0 14px;
            font-size: 18px;
        }

        .chart {
            width: 100%;
            min-height: 270px;
        }

        .table-card { overflow-x: auto; }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
            min-width: 1250px;
        }

        thead {
            background: #102f4d;
            color: white;
        }

        th,
        td {
            padding: 13px 12px;
            text-align: left;
            border-bottom: 1px solid #e6eaf0;
            vertical-align: middle;
        }

        tbody tr { background: white; }
        tbody tr:hover { background: #f3f8fd; }

        .pill {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
        }

        .pill-new { background: #e8f3ff; color: #174a7c; }
        .pill-progress { background: #fff3cd; color: #8a6500; }
        .pill-complete { background: #dff6e6; color: #18733b; }
        .pill-overdue { background: #fde2e2; color: #b42318; }
        .pill-urgent { background: #fde2e2; color: #b42318; }
        .pill-high { background: #fff1d6; color: #9a5b00; }
        .pill-normal { background: #e8f3ff; color: #174a7c; }
        .pill-low { background: #ecfdf3; color: #18733b; }
        .pill-hold { background: #eee7ff; color: #5b3cc4; }

        .empty {
            padding: 30px;
            text-align: center;
            color: var(--muted);
        }

        .axis text {
            fill: #667085;
            font-size: 12px;
        }

        .axis path,
        .axis line {
            stroke: #d0d7de;
        }

        .tooltip {
            position: fixed;
            pointer-events: none;
            background: #0b1f33;
            color: white;
            padding: 9px 12px;
            border-radius: 10px;
            font-size: 13px;
            opacity: 0;
            box-shadow: 0 12px 30px rgba(0,0,0,0.25);
            z-index: 99;
        }

        .admin-badge {
            background: #dff6e6;
            color: #18733b;
            padding: 8px 12px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 700;
        }

        .admin-actions {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        .inline-form {
            display: flex;
            gap: 8px;
            align-items: center;
            margin: 0;
        }

        .inline-form select,
        .inline-form input {
            min-width: 165px;
            padding: 8px 10px;
        }

        .inline-form button {
            margin: 0;
            padding: 8px 10px;
        }

        @media (max-width: 1100px) {
            .kpis { grid-template-columns: repeat(2, 1fr); }
            .grid { grid-template-columns: 1fr; }
            .wide { grid-column: span 1; }
            .topbar {
                flex-direction: column;
                align-items: stretch;
            }
        }

        @media (max-width: 700px) {
            .kpis { grid-template-columns: 1fr; }
            .hero { padding: 26px 22px 80px; }
            .dashboard { padding: 0 14px; }
        }
    </style>
</head>

<body>

<div class="hero">
    <h1>Data Analytics Team (DAT) Request Dashboard</h1>
    <p>Live operational view of GIS, mapping, dashboard, and spatial analysis requests.</p>
</div>

<div class="dashboard">

    <div class="topbar">
        <div class="filters">
            <input type="text" id="searchBox" placeholder="Search requests...">

            <select id="officeFilter">
                <option value="">All Offices / Programs</option>
            </select>

            <select id="priorityFilter">
                <option value="">All Priorities</option>
            </select>

            <select id="statusFilter">
                <option value="">All Statuses</option>
            </select>

            <button class="btn" onclick="resetFilters()">Reset</button>
        </div>

        <div class="admin-actions">
            <?php if ($isLoggedIn): ?>
                <span class="admin-badge">Admin Mode</span>
                <a class="btn" href="logout.php">Logout</a>
            <?php else: ?>
                <a class="btn" href="login.php">Admin Login</a>
            <?php endif; ?>

            <a class="btn" href="index.php">New Request</a>
        </div>
    </div>

    <div class="kpis">
        <div class="card kpi">
            <div class="kpi-label">Total Requests</div>
            <div class="kpi-value" id="kpiTotal">0</div>
            <div class="kpi-note">All captured requests</div>
        </div>

        <div class="card kpi">
            <div class="kpi-label">Open Requests</div>
            <div class="kpi-value" id="kpiOpen">0</div>
            <div class="kpi-note">Not complete or cancelled</div>
        </div>

        <div class="card kpi">
            <div class="kpi-label">Urgent / High</div>
            <div class="kpi-value" id="kpiCritical">0</div>
            <div class="kpi-note">Priority workload pressure</div>
        </div>

        <div class="card kpi">
            <div class="kpi-label">Overdue</div>
            <div class="kpi-value" id="kpiOverdue">0</div>
            <div class="kpi-note">Past requested due date</div>
        </div>

        <div class="card kpi">
            <div class="kpi-label">Avg Days Left</div>
            <div class="kpi-value" id="kpiAvgDays">0</div>
            <div class="kpi-note">Based on due dates</div>
        </div>
    </div>

    <div class="grid">
        <div class="card wide">
            <h2>Requests by Office / Program</h2>
            <div id="officeChart" class="chart"></div>
        </div>

        <div class="card">
            <h2>Status Breakdown</h2>
            <div id="statusChart" class="chart"></div>
        </div>

        <div class="card">
            <h2>Priority Mix</h2>
            <div id="priorityChart" class="chart"></div>
        </div>

        <div class="card">
            <h2>Specialist Workload</h2>
            <div id="specialistChart" class="chart"></div>
        </div>

        <div class="card wide">
            <h2>Days Remaining by Request</h2>
            <div id="daysChart" class="chart"></div>
        </div>
    </div>

    <div class="card table-card">
        <h2>Request Queue</h2>
        <div id="tableWrap"></div>
    </div>

</div>

<div class="tooltip" id="tooltip"></div>

<script>
const rawData = <?php echo $requestsJson ?: "[]"; ?>;
const isLoggedIn = <?php echo $isLoggedIn ? "true" : "false"; ?>;

const data = rawData.map(d => ({
    requestId: d["Request ID"] || "",
    submittedDate: d["Submitted Date"] || "",
    status: d["Status"] || "New",
    assignedSpecialist: d["Assigned Specialist"] || "",
    requester: d["Requester Name"] || "",
    email: d["Email"] || "",
    office: d["Office / Program"] || d["Division"] || "",
    requestType: d["Request Type"] || "",
    priority: d["Priority"] || "",
    dueDate: d["Due Date"] || "",
    daysLeft: d["Days Left"] === "" ? null : Number(d["Days Left"]),
    location: d["Location"] || "",
    description: d["Description"] || "",
    outputType: d["Output Type"] || ""
}));

let filteredData = [...data];

const tooltip = d3.select("#tooltip");

function uniqueValues(field) {
    return [...new Set(data.map(d => d[field]).filter(Boolean))].sort();
}

function populateFilters() {
    populateSelect("officeFilter", uniqueValues("office"));
    populateSelect("priorityFilter", uniqueValues("priority"));
    populateSelect("statusFilter", uniqueValues("status"));
}

function populateSelect(id, values) {
    const select = document.getElementById(id);

    values.forEach(v => {
        const option = document.createElement("option");
        option.value = v;
        option.textContent = v;
        select.appendChild(option);
    });
}

function applyFilters() {
    const search = document.getElementById("searchBox").value.toLowerCase();
    const office = document.getElementById("officeFilter").value;
    const priority = document.getElementById("priorityFilter").value;
    const status = document.getElementById("statusFilter").value;

    filteredData = data.filter(d => {
        const searchable = Object.values(d).join(" ").toLowerCase();

        return (!search || searchable.includes(search)) &&
               (!office || d.office === office) &&
               (!priority || d.priority === priority) &&
               (!status || d.status === status);
    });

    renderAll();
}

function resetFilters() {
    document.getElementById("searchBox").value = "";
    document.getElementById("officeFilter").value = "";
    document.getElementById("priorityFilter").value = "";
    document.getElementById("statusFilter").value = "";

    filteredData = [...data];
    renderAll();
}

function statusClass(status) {
    const s = String(status || "").toLowerCase();

    if (s.includes("complete")) return "pill-complete";
    if (s.includes("progress")) return "pill-progress";
    if (s.includes("pending")) return "pill-progress";
    if (s.includes("hold")) return "pill-hold";
    if (s.includes("cancel")) return "pill-overdue";
    if (s.includes("issue") || s.includes("blocked")) return "pill-overdue";

    return "pill-new";
}

function priorityClass(priority) {
    const p = String(priority || "").toLowerCase();

    if (p === "urgent") return "pill-urgent";
    if (p === "high") return "pill-high";
    if (p === "normal") return "pill-normal";
    if (p === "low") return "pill-low";

    return "pill-normal";
}

function renderKpis() {
    const total = filteredData.length;

    const open = filteredData.filter(d => {
        const s = d.status.toLowerCase();
        return !s.includes("complete") && !s.includes("cancel");
    }).length;

    const critical = filteredData.filter(d =>
        ["urgent", "high"].includes(d.priority.toLowerCase())
    ).length;

    const overdue = filteredData.filter(d => {
        const s = d.status.toLowerCase();

        return d.daysLeft !== null &&
               d.daysLeft < 0 &&
               !s.includes("complete") &&
               !s.includes("cancel");
    }).length;

    const days = filteredData
        .map(d => d.daysLeft)
        .filter(d => d !== null && !isNaN(d));

    const avgDays = days.length ? Math.round(d3.mean(days)) : 0;

    animateNumber("#kpiTotal", total);
    animateNumber("#kpiOpen", open);
    animateNumber("#kpiCritical", critical);
    animateNumber("#kpiOverdue", overdue);
    animateNumber("#kpiAvgDays", avgDays);
}

function animateNumber(selector, value) {
    const el = document.querySelector(selector);
    const obj = { val: Number(el.textContent) || 0 };

    gsap.to(obj, {
        val: value,
        duration: 0.7,
        ease: "power2.out",
        onUpdate: () => {
            el.textContent = Math.round(obj.val);
        }
    });
}

function countBy(field) {
    return Array.from(
        d3.rollup(
            filteredData,
            v => v.length,
            d => {
                if (field === "assignedSpecialist") {
                    return d[field] || "Unassigned";
                }

                return d[field] || "Unknown";
            }
        ),
        ([key, value]) => ({ key, value })
    ).sort((a, b) => d3.descending(a.value, b.value));
}

function clearChart(id) {
    d3.select(id).selectAll("*").remove();
}

function renderBarChart(id, chartData) {
    clearChart(id);

    const container = document.querySelector(id);
    const width = container.clientWidth;
    const height = 270;
    const margin = { top: 20, right: 24, bottom: 55, left: 48 };

    const svg = d3.select(id)
        .append("svg")
        .attr("width", width)
        .attr("height", height);

    if (!chartData.length) return;

    const x = d3.scaleBand()
        .domain(chartData.map(d => d.key))
        .range([margin.left, width - margin.right])
        .padding(0.28);

    const y = d3.scaleLinear()
        .domain([0, d3.max(chartData, d => d.value)])
        .nice()
        .range([height - margin.bottom, margin.top]);

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", `translate(0,${height - margin.bottom})`)
        .call(d3.axisBottom(x))
        .selectAll("text")
        .attr("transform", "rotate(-25)")
        .style("text-anchor", "end");

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", `translate(${margin.left},0)`)
        .call(d3.axisLeft(y).ticks(5));

    svg.selectAll(".bar")
        .data(chartData)
        .enter()
        .append("rect")
        .attr("x", d => x(d.key))
        .attr("y", y(0))
        .attr("width", x.bandwidth())
        .attr("height", 0)
        .attr("rx", 8)
        .attr("fill", "#174a7c")
        .on("mousemove", function(event, d) {
            tooltip
                .style("opacity", 1)
                .style("left", event.clientX + 12 + "px")
                .style("top", event.clientY + 12 + "px")
                .html(`<strong>${d.key}</strong><br>${d.value} request(s)`);
        })
        .on("mouseleave", () => tooltip.style("opacity", 0))
        .transition()
        .duration(850)
        .ease(d3.easeCubicOut)
        .attr("y", d => y(d.value))
        .attr("height", d => y(0) - y(d.value));

    svg.selectAll(".label")
        .data(chartData)
        .enter()
        .append("text")
        .attr("x", d => x(d.key) + x.bandwidth() / 2)
        .attr("y", d => y(d.value) - 8)
        .attr("text-anchor", "middle")
        .attr("font-weight", "700")
        .attr("fill", "#102f4d")
        .text(d => d.value)
        .style("opacity", 0)
        .transition()
        .delay(400)
        .duration(500)
        .style("opacity", 1);
}

function renderDonut(id, chartData) {
    clearChart(id);

    const container = document.querySelector(id);
    const width = container.clientWidth;
    const height = 270;
    const radius = Math.min(width, height) / 2 - 24;

    const svg = d3.select(id)
        .append("svg")
        .attr("width", width)
        .attr("height", height)
        .append("g")
        .attr("transform", `translate(${width / 2},${height / 2})`);

    if (!chartData.length) return;

    const color = d3.scaleOrdinal()
        .domain(chartData.map(d => d.key))
        .range([
            "#174a7c",
            "#37b6ff",
            "#ffc107",
            "#28a745",
            "#dc3545",
            "#7b61ff",
            "#6c757d",
            "#20c997",
            "#fd7e14"
        ]);

    const pie = d3.pie()
        .value(d => d.value)
        .sort(null);

    const arc = d3.arc()
        .innerRadius(radius * 0.58)
        .outerRadius(radius);

    svg.selectAll("path")
        .data(pie(chartData))
        .enter()
        .append("path")
        .attr("fill", d => color(d.data.key))
        .attr("stroke", "white")
        .attr("stroke-width", 3)
        .on("mousemove", function(event, d) {
            tooltip
                .style("opacity", 1)
                .style("left", event.clientX + 12 + "px")
                .style("top", event.clientY + 12 + "px")
                .html(`<strong>${d.data.key}</strong><br>${d.data.value} request(s)`);
        })
        .on("mouseleave", () => tooltip.style("opacity", 0))
        .transition()
        .duration(900)
        .attrTween("d", function(d) {
            const i = d3.interpolate({ startAngle: 0, endAngle: 0 }, d);
            return t => arc(i(t));
        });

    svg.append("text")
        .attr("text-anchor", "middle")
        .attr("font-size", "32px")
        .attr("font-weight", "800")
        .attr("fill", "#102f4d")
        .text(d3.sum(chartData, d => d.value));

    svg.append("text")
        .attr("text-anchor", "middle")
        .attr("y", 24)
        .attr("font-size", "12px")
        .attr("fill", "#667085")
        .text("Requests");
}

function renderDaysChart() {
    clearChart("#daysChart");

    const chartData = filteredData
        .filter(d => d.daysLeft !== null && !isNaN(d.daysLeft))
        .slice()
        .sort((a, b) => d3.ascending(a.daysLeft, b.daysLeft))
        .slice(0, 12);

    const container = document.querySelector("#daysChart");
    const width = container.clientWidth;
    const height = 270;
    const margin = { top: 20, right: 32, bottom: 45, left: 120 };

    const svg = d3.select("#daysChart")
        .append("svg")
        .attr("width", width)
        .attr("height", height);

    if (!chartData.length) return;

    const min = d3.min(chartData, d => d.daysLeft);
    const max = d3.max(chartData, d => d.daysLeft);

    const x = d3.scaleLinear()
        .domain([Math.min(min, 0), Math.max(max, 1)])
        .nice()
        .range([margin.left, width - margin.right]);

    const y = d3.scaleBand()
        .domain(chartData.map(d => d.requestId))
        .range([margin.top, height - margin.bottom])
        .padding(0.25);

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", `translate(0,${height - margin.bottom})`)
        .call(d3.axisBottom(x).ticks(6));

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", `translate(${margin.left},0)`)
        .call(d3.axisLeft(y));

    svg.append("line")
        .attr("x1", x(0))
        .attr("x2", x(0))
        .attr("y1", margin.top)
        .attr("y2", height - margin.bottom)
        .attr("stroke", "#dc3545")
        .attr("stroke-dasharray", "5,5");

    svg.selectAll("rect")
        .data(chartData)
        .enter()
        .append("rect")
        .attr("x", d => d.daysLeft < 0 ? x(d.daysLeft) : x(0))
        .attr("y", d => y(d.requestId))
        .attr("width", 0)
        .attr("height", y.bandwidth())
        .attr("rx", 7)
        .attr("fill", d => d.daysLeft < 0 ? "#dc3545" : "#28a745")
        .on("mousemove", function(event, d) {
            tooltip
                .style("opacity", 1)
                .style("left", event.clientX + 12 + "px")
                .style("top", event.clientY + 12 + "px")
                .html(`<strong>${d.requestId}</strong><br>${d.daysLeft} day(s)<br>${d.requester}`);
        })
        .on("mouseleave", () => tooltip.style("opacity", 0))
        .transition()
        .duration(900)
        .attr("width", d => Math.abs(x(d.daysLeft) - x(0)));
}

function renderStatusControl(d) {
    if (!isLoggedIn) {
        return `<span class="pill ${statusClass(d.status)}">${escapeHtml(d.status)}</span>`;
    }

    const statuses = [
        "New",
        "Assigned",
        "In Progress",
        "Pending Customer",
        "Pending Data",
        "Pending Review",
        "On Hold",
        "Completed",
        "Cancelled",
        "Issue / Blocked"
    ];

    const options = statuses.map(s => {
        const selected = s === d.status ? "selected" : "";
        return `<option value="${escapeHtml(s)}" ${selected}>${escapeHtml(s)}</option>`;
    }).join("");

    return `
        <form method="POST" action="update_status.php" class="inline-form">
            <input type="hidden" name="request_id" value="${escapeHtml(d.requestId)}">
            <select name="status">
                ${options}
            </select>
            <button class="btn" type="submit">Save</button>
        </form>
    `;
}

function renderAssignmentControl(d) {
    if (!isLoggedIn) {
        return d.assignedSpecialist
            ? `<span class="pill pill-normal">${escapeHtml(d.assignedSpecialist)}</span>`
            : `<span class="pill pill-new">Unassigned</span>`;
    }

    const specialists = [
        "",
        "Specialist A",
        "Specialist B",
        "Specialist C"
    ];

    const options = specialists.map(s => {
        const selected = s === d.assignedSpecialist ? "selected" : "";
        const label = s === "" ? "Unassigned" : s;
        return `<option value="${escapeHtml(s)}" ${selected}>${escapeHtml(label)}</option>`;
    }).join("");

    return `
        <form method="POST" action="update_assignment.php" class="inline-form">
            <input type="hidden" name="request_id" value="${escapeHtml(d.requestId)}">
            <select name="assigned_specialist">
                ${options}
            </select>
            <button class="btn" type="submit">Save</button>
        </form>
    `;
}

function renderTable() {
    const wrap = document.getElementById("tableWrap");

    if (!filteredData.length) {
        wrap.innerHTML = `<div class="empty">No requests match the current filters.</div>`;
        return;
    }

    const rows = filteredData.map(d => {
        const daysDisplay =
            d.daysLeft === null ? "" :
            d.daysLeft < 0 ? `<span class="pill pill-overdue">${Math.abs(d.daysLeft)} days overdue</span>` :
            d.daysLeft === 0 ? `<span class="pill pill-high">Due today</span>` :
            `<span class="pill pill-complete">${d.daysLeft} days left</span>`;

        return `
            <tr>
                <td><strong>${escapeHtml(d.requestId)}</strong></td>
                <td>${escapeHtml(d.submittedDate)}</td>
                <td>${escapeHtml(d.requester)}</td>
                <td>${escapeHtml(d.office)}</td>
                <td>${escapeHtml(d.requestType)}</td>
                <td><span class="pill ${priorityClass(d.priority)}">${escapeHtml(d.priority)}</span></td>
                <td>${renderStatusControl(d)}</td>
                <td>${renderAssignmentControl(d)}</td>
                <td>${escapeHtml(d.dueDate)}</td>
                <td>${daysDisplay}</td>
                <td>${escapeHtml(d.location)}</td>
            </tr>
        `;
    }).join("");

    wrap.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th>Request ID</th>
                    <th>Submitted</th>
                    <th>Requester</th>
                    <th>Office / Program</th>
                    <th>Type</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Assigned Specialist</th>
                    <th>Due Date</th>
                    <th>Days</th>
                    <th>Location</th>
                </tr>
            </thead>
            <tbody>${rows}</tbody>
        </table>
    `;

    gsap.from("tbody tr", {
        opacity: 0,
        y: 12,
        duration: 0.45,
        stagger: 0.035,
        ease: "power2.out"
    });
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function renderAll() {
    renderKpis();
    renderBarChart("#officeChart", countBy("office"));
    renderDonut("#statusChart", countBy("status"));
    renderDonut("#priorityChart", countBy("priority"));
    renderDonut("#specialistChart", countBy("assignedSpecialist"));
    renderDaysChart();
    renderTable();

    gsap.from(".card", {
        opacity: 0,
        y: 18,
        duration: 0.6,
        stagger: 0.045,
        ease: "power2.out"
    });
}

document.getElementById("searchBox").addEventListener("input", applyFilters);
document.getElementById("officeFilter").addEventListener("change", applyFilters);
document.getElementById("priorityFilter").addEventListener("change", applyFilters);
document.getElementById("statusFilter").addEventListener("change", applyFilters);

window.addEventListener("resize", renderAll);

populateFilters();
renderAll();

gsap.from(".hero h1", {
    opacity: 0,
    y: -20,
    duration: 0.8,
    ease: "power3.out"
});

gsap.from(".hero p", {
    opacity: 0,
    y: -10,
    duration: 0.8,
    delay: 0.15,
    ease: "power3.out"
});

gsap.from(".filters", {
    opacity: 0,
    y: 20,
    duration: 0.7,
    delay: 0.25,
    ease: "power3.out"
});
</script>

</body>
</html>