<?php
session_start();

$ADMIN_USERNAME = "datadmin";

// Change this password
$ADMIN_PASSWORD = "rockclimbingheroes!";

function is_logged_in() {
    return isset($_SESSION["gis_admin_logged_in"]) && $_SESSION["gis_admin_logged_in"] === true;
}