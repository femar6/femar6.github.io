<?php
require_once "auth.php";

if (!is_logged_in()) {
    die("Unauthorized.");
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: dashboard.php");
    exit;
}

$request_id = $_POST["request_id"] ?? "";
$assigned_specialist = trim($_POST["assigned_specialist"] ?? "");

$allowed_specialists = [
    "",
    "Specialist A",
    "Specialist B",
    "Specialist C"
];

if (!$request_id || !in_array($assigned_specialist, $allowed_specialists, true)) {
    die("Invalid assignment.");
}

$file = "requests.csv";
$rows = [];

if (($handle = fopen($file, "r")) !== false) {
    while (($row = fgetcsv($handle)) !== false) {
        if (count($row) === 0 || (count($row) === 1 && trim($row[0]) === "")) {
            continue;
        }

        $rows[] = $row;
    }

    fclose($handle);
}

if (empty($rows)) {
    die("CSV is empty.");
}

$headers = $rows[0];

$requestIdIndex = array_search("Request ID", $headers);
$statusIndex = array_search("Status", $headers);
$assignedIndex = array_search("Assigned Specialist", $headers);

if ($requestIdIndex === false) {
    die("Request ID column missing.");
}

if ($assignedIndex === false) {
    if ($statusIndex === false) {
        die("Status column missing.");
    }

    array_splice($headers, $statusIndex + 1, 0, "Assigned Specialist");
    $assignedIndex = $statusIndex + 1;
    $rows[0] = $headers;

    for ($i = 1; $i < count($rows); $i++) {
        array_splice($rows[$i], $assignedIndex, 0, "");
    }
}

for ($i = 1; $i < count($rows); $i++) {
    if (($rows[$i][$requestIdIndex] ?? "") === $request_id) {
        $rows[$i][$assignedIndex] = $assigned_specialist;
        break;
    }
}

if (($handle = fopen($file, "w")) !== false) {
    foreach ($rows as $row) {
        fputcsv($handle, $row);
    }

    fclose($handle);
}

header("Location: dashboard.php");
exit;