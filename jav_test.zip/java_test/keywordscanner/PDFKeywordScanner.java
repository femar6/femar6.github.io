import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PDFKeywordScanner extends JFrame {

    private JTextArea resultArea;
    private final List<String> keywords = Arrays.asList(
            "EO", "Executive Order", "Disadvantaged", "Marginalized", "Underserved",
            "Underserved Communities", "Low-Income", "Environmental Justice", "Climate",
            "Climate Change", "Equity", "Equitable", "Inclusion", "Diverse", "Diversity",
            "Minority", "Affirmative Action", "Accessibility", "Culture",
            "Federal Flood Risk Management Standard", "FFRMS", "Justice40", "J40", "Justice",
            "Vulnerable", "Climate and Economic Justice Screening Tool", "CJEST", "SoVI", "SOVI",
            "Future Conditions", "Resiliency", "Resilient"
    );
    private final List<String[]> matches = new ArrayList<>();

    public PDFKeywordScanner() {
        setTitle("PDF Keyword Search");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JButton selectButton = new JButton("Select Directory");
        resultArea = new JTextArea();
        resultArea.setEditable(false);

        selectButton.addActionListener(e -> selectDirectory());

        add(selectButton, BorderLayout.NORTH);
        add(new JScrollPane(resultArea), BorderLayout.CENTER);
    }

    private void selectDirectory() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int option = chooser.showOpenDialog(this);

        if (option == JFileChooser.APPROVE_OPTION) {
            File directory = chooser.getSelectedFile();
            resultArea.setText("");
            matches.clear();
            scanPDFs(directory);
            exportCSV(directory);
        }
    }

    private void scanPDFs(File directory) {
        File[] pdfFiles = directory.listFiles((dir, name) -> name.toLowerCase().endsWith(".pdf"));
        if (pdfFiles == null) return;

        for (File pdf : pdfFiles) {
            try (PDDocument document = PDDocument.load(pdf)) {
                PDFTextStripper stripper = new PDFTextStripper();
                String fullText = stripper.getText(document);
                String[] lines = fullText.split("\r?\n");

                for (int i = 0; i < lines.length; i++) {
                    String line = lines[i];
                    List<String> found = new ArrayList<>();
                    for (String keyword : keywords) {
                        if (line.toLowerCase().contains(keyword.toLowerCase())) {
                            found.add(keyword);
                        }
                    }
                    if (!found.isEmpty()) {
                        String result = String.format("%s - Page 1, Line %d: %s", pdf.getName(), i + 1, String.join(", ", found));
                        resultArea.append(result + "\n");
                        matches.add(new String[]{pdf.getName(), "1", String.valueOf(i + 1), String.join(", ", found), line.trim()});
                    }
                }
            } catch (IOException e) {
                resultArea.append("Failed to read: " + pdf.getName() + "\n");
            }
        }
    }

    private void exportCSV(File directory) {
        if (matches.isEmpty()) {
            resultArea.append("No data to export.\n");
            return;
        }

        File csvFile = new File(directory, "search_results.csv");
        try (PrintWriter writer = new PrintWriter(new FileWriter(csvFile))) {
            writer.println("File Name,Page Number,Line Number,Found Words,Text Snippet");
            for (String[] match : matches) {
                writer.printf("\"%s\",%s,%s,\"%s\",\"%s\"%n",
                        match[0], match[1], match[2], match[3], match[4]);
            }
            resultArea.append("Results exported to: " + csvFile.getAbsolutePath() + "\n");
        } catch (IOException e) {
            resultArea.append("Error writing CSV file.\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PDFKeywordScanner().setVisible(true));
    }
}
