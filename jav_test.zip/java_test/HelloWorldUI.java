import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class HelloWorldUI {

    public static void createAndShowGUI() {
        // Create the main window (JFrame)
        JFrame frame = new JFrame("Hello World App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setLayout(null); // We'll use absolute positioning

        // Create a button
        JButton button = new JButton("Click Me!");
        button.setBounds(90, 70, 120, 40); // x, y, width, height

        // Add an action listener to the button
        button.addActionListener(e -> {
            JOptionPane.showMessageDialog(frame, "Hello World!");
        });

        // Add button to frame
        frame.add(button);

        // Show the frame
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(HelloWorldUI::createAndShowGUI);
    }
}
