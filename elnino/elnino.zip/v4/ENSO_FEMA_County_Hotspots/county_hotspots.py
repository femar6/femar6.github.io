"""Cache-first county extension for the preserved Region 6 application."""
import json
import sqlite3
import threading
import traceback
import webbrowser
from pathlib import Path

import numpy as np
import pandas as pd

BOUNDARY_URL = 'https://www2.census.gov/geo/tiger/GENZ2024/shp/cb_2024_us_county_500k.zip'
STATE_FIPS = {'05': 'AR', '22': 'LA', '35': 'NM', '40': 'OK', '48': 'TX'}
PHASES = ['El Nino', 'La Nina', 'Neutral']


def fips_part(value, width):
    try:
        n = float(value)
        if not np.isfinite(n) or n != int(n) or not 0 <= n < 10 ** width:
            return None
        return str(int(n)).zfill(width)
    except (ValueError, TypeError):
        return None


def county_rates(fema, roni, counties, start, end, phase, hazard, analyze, log):
    # Recompute derived fields when loading an older joined SQLite table.
    derived = ['incident_month', 'incident_type', 'hazard_group', 'weather_included',
               'disaster_key', 'year_month', 'roni', 'enso_phase', 'strength']
    raw = fema.drop(columns=derived, errors='ignore')
    normalized, events, panel, summary, hazards, qa = analyze(raw, roni, start, end, log)
    f = normalized.copy()
    s = f.fipsStateCode.map(lambda x: fips_part(x, 2))
    c = f.fipsCountyCode.map(lambda x: fips_part(x, 3))
    f['GEOID'] = s.fillna('') + c.fillna('')
    f['county_join_status'] = np.where(s.isna() | c.isna(), 'invalid_fips',
        np.where(c.eq('000'), 'statewide_or_unspecified',
        np.where(f.GEOID.isin(counties.GEOID), 'matched', 'unmatched_boundary')))
    eligible = f.weather_included & f.enso_phase.notna()
    if hazard != 'All weather':
        eligible &= f.hazard_group.eq(hazard)
    selected = f[eligible & f.county_join_status.eq('matched')].drop_duplicates(['GEOID', 'disaster_key'])
    # Every boundary county has every observed phase month, including zero-event months.
    months = pd.DataFrame({'year_month': pd.period_range(start[:7], end[:7], freq='M').astype(str)})
    months = months.merge(roni[['year_month', 'enso_phase']], on='year_month', how='left', validate='one_to_one')
    exposure = months.enso_phase.value_counts()
    counts = selected.groupby(['GEOID', 'enso_phase']).size()
    result = counties.copy()
    for label, prefix in [('El Nino', 'el_nino'), ('La Nina', 'la_nina'), ('Neutral', 'neutral')]:
        result[prefix + '_months'] = int(exposure.get(label, 0))
        result[prefix + '_count'] = result.GEOID.map(counts.xs(label, level=1) if label in counts.index.get_level_values(1) else {}).fillna(0).astype(int)
        result[prefix + '_rate'] = result[prefix + '_count'] * 12 / (exposure.get(label, 0) or np.nan)
    prefix = {'El Nino': 'el_nino', 'La Nina': 'la_nina'}[phase]
    result['rate_difference'] = result[prefix + '_rate'] - result.neutral_rate
    result['rate_ratio'] = result[prefix + '_rate'] / result.neutral_rate.replace(0, np.nan)
    result['comparison_phase'] = phase
    result['hazard_filter'] = hazard
    result['low_count'] = result[prefix + '_count'].lt(5) | result.neutral_count.lt(5)
    tables = dict(zip(['fema_designations_joined', 'unique_declarations', 'state_month_panel',
                      'phase_summary', 'hazard_summary', 'quality_checks'],
                     [normalized, events, panel, summary, hazards, qa]))
    tables.update(roni_monthly=roni, county_designations=selected,
                  county_join_audit=f[~f.county_join_status.eq('matched')],
                  county_exposure_months=months)
    return result, tables


def bh_adjust(p):
    p = np.asarray(p, dtype=float)
    order = np.argsort(p)
    adjusted = np.minimum.accumulate((p[order] * len(p) / np.arange(1, len(p)+1))[::-1])[::-1]
    out = np.empty(len(p)); out[order] = np.minimum(adjusted, 1)
    return out


def spatial_tests(gdf, method, log):
    if method == 'None':
        return gdf
    from libpysal.weights import Queen
    from esda import G_Local, Moran_Local
    gdf = gdf.reset_index(drop=True)
    y = gdf.rate_difference.to_numpy(float)
    if not np.isfinite(y).all() or np.std(y) == 0:
        raise ValueError('Spatial tests require both phase exposures and a nonconstant rate difference.')
    w = Queen.from_dataframe(gdf, use_index=True)
    islands = np.array([i in w.islands for i in range(len(gdf))])
    gdf['neighbor_count'] = [len(w.neighbors[i]) for i in range(len(gdf))]
    # Islands receive no significance labels; do not invent cross-border neighbors.
    if method in ('Gi*', 'Both'):
        # Gi* uses nonnegative selected-phase rates, since signed differences can have a zero sum.
        prefix = {'El Nino': 'el_nino', 'La Nina': 'la_nina'}[gdf.comparison_phase.iloc[0]]
        gy = gdf[prefix + '_rate'].to_numpy(float)
        if np.std(gy) == 0:
            raise ValueError('Gi* requires nonconstant selected-phase rates.')
        stat = G_Local(gy, w, transform='B', star=True, permutations=999,
                       seed=24601, n_jobs=1, keep_simulations=False)
        gdf['gi_z'] = stat.Zs
        # Explicit two-sided normal probabilities from the analytical z scores.
        from scipy.stats import norm
        p = 2 * norm.sf(np.abs(stat.Zs))
        valid = ~islands & np.isfinite(p)
        gdf['gi_p'] = np.where(valid, p, np.nan)
        gdf['gi_q'] = np.nan
        gdf.loc[valid, 'gi_q'] = bh_adjust(p[valid])
        gdf['gi_class'] = np.where(islands, 'Island', np.where(gdf.gi_q.le(.05),
                                    np.where(gdf.gi_z.gt(0), 'Hot spot', 'Cold spot'), 'Not significant'))
    if method in ('Local Moran', 'Both'):
        stat = Moran_Local(y, w, permutations=999, seed=24601, n_jobs=1, keep_simulations=False)
        p = np.minimum(1, 2 * stat.p_sim)
        valid = ~islands & np.isfinite(p)
        gdf['moran_i'] = stat.Is
        gdf['moran_p'] = np.where(valid, p, np.nan)
        gdf['moran_q'] = np.nan
        gdf.loc[valid, 'moran_q'] = bh_adjust(p[valid])
        labels = pd.Series(stat.q).map({1:'High-High', 2:'Low-High', 3:'Low-Low', 4:'High-Low'})
        gdf['moran_class'] = np.where(islands, 'Island', np.where(gdf.moran_q.le(.05), labels, 'Not significant'))
    log('Spatial tests complete; significance labels use Benjamini-Hochberg q <= 0.05.')
    return gdf


def load_cache(source, start, end):
    source = Path(source)
    folder = source.parent if source.is_file() else source
    meta_path = folder / 'run_metadata.json'
    if not meta_path.exists():
        raise ValueError('Cache needs run_metadata.json to verify coverage. Select the original analysis folder.')
    meta = json.loads(meta_path.read_text(encoding='utf-8'))
    if start < meta['start'] or end > meta['end']:
        raise ValueError(f"Requested dates exceed cached coverage {meta['start']} to {meta['end']}. Narrow dates or select Refresh.")
    db_path = source if source.is_file() else folder / 'ENSO_FEMA_Region6.sqlite'
    if db_path.exists():
        with sqlite3.connect(f'{db_path.resolve().as_uri()}?mode=ro', uri=True) as db:
            roni = pd.read_sql_query('SELECT * FROM roni_monthly', db)
            raw_json = folder / 'raw' / 'fema_designations.json'
            fema = pd.read_json(raw_json) if raw_json.exists() else pd.read_sql_query('SELECT * FROM fema_designations_joined', db)
    else:
        roni = pd.read_csv(folder / 'roni_monthly.csv')
        raw_json = folder / 'raw' / 'fema_designations.json'
        fema = pd.read_json(raw_json) if raw_json.exists() else pd.read_csv(folder / 'fema_designations_joined.csv')
    return fema, roni, meta


def run_counties(api, output, source, start, end, phase, hazard, method, boundary, refresh, log):
    import geopandas as gpd
    import folium
    output = Path(output)
    source_path = Path(source)
    source_folder = source_path.parent if source_path.is_file() else source_path
    if not refresh and output.resolve() == source_folder.resolve():
        raise ValueError('Choose an output folder different from the input cache folder.')
    output.mkdir(parents=True, exist_ok=True)
    if refresh:
        raw_dir = output / 'raw'; raw_dir.mkdir(exist_ok=True)
        with api['requests'].Session() as session:
            text, roni = api['fetch_roni'](session, log)
            fema = api['fetch_fema'](session, start, end, log)
        (raw_dir / 'RONI.ascii.txt').write_text(text, encoding='utf-8')
        fema.to_json(raw_dir / 'fema_designations.json', orient='records', date_format='iso')
        source_meta = {'start':start, 'end':end}
    else:
        fema, roni, source_meta = load_cache(source, start, end)
        log('Using cached FEMA and NOAA data; no source downloads.')
    if boundary:
        boundary_path = Path(boundary)
    else:
        boundary_path = output / 'boundaries' / 'cb_2024_us_county_500k.zip'
        if not boundary_path.exists():
            log('Downloading Census county boundaries once...')
            response = api['requests'].get(BOUNDARY_URL, timeout=120); response.raise_for_status()
            boundary_path.parent.mkdir(exist_ok=True)
            boundary_path.write_bytes(response.content)
    counties = gpd.read_file(boundary_path)
    if counties.crs is None:
        raise ValueError('Boundary file must have a defined CRS.')
    if 'GEOID' not in counties or 'NAME' not in counties:
        raise ValueError('County boundaries need GEOID and NAME fields.')
    counties['GEOID'] = counties.GEOID.map(lambda x: fips_part(x, 5))
    counties = counties[counties.GEOID.str[:2].isin(STATE_FIPS)].copy()
    if counties.empty or counties.GEOID.duplicated().any() or counties.geometry.isna().any() or not counties.geometry.is_valid.all():
        raise ValueError('Boundaries must contain unique, valid Region 6 county geometries.')
    counties = counties[['GEOID', 'NAME', 'geometry']].to_crs(4326).reset_index(drop=True)
    counties['state'] = counties.GEOID.str[:2].map(STATE_FIPS)
    result, tables = county_rates(fema, roni, counties, start, end, phase, hazard, api['analyze'], log)
    result = spatial_tests(result, method, log)
    tables['county_hotspots'] = pd.DataFrame(result.drop(columns='geometry'))
    for name, df in tables.items():
        df.to_csv(output / (name + '.csv'), index=False)
    with pd.ExcelWriter(output / 'ENSO_FEMA_Region6.xlsx', engine='openpyxl') as writer:
        for name, df in tables.items():
            api['excel_safe_dataframe'](df).to_excel(writer, sheet_name=name[:31], index=False)
    with sqlite3.connect(output / 'ENSO_FEMA_Region6.sqlite') as db:
        for name, df in tables.items():
            df.to_sql(name, db, if_exists='replace', index=False)
    result.to_file(output / 'county_hotspots.geojson', driver='GeoJSON')
    result.to_file(output / 'county_hotspots.gpkg', layer='county_hotspots', driver='GPKG')
    m = folium.Map(location=[33, -99], zoom_start=5, tiles=None)
    folium.TileLayer('OpenStreetMap').add_to(m)
    for metric in ['rate_difference', 'rate_ratio', 'el_nino_rate', 'la_nina_rate', 'neutral_rate']:
        folium.Choropleth(geo_data=result.to_json(), data=result, columns=['GEOID', metric],
            key_on='feature.properties.GEOID', name=metric, fill_color='YlOrRd',
            nan_fill_color='#aaaaaa', legend_name=metric, show=metric=='rate_difference').add_to(m)
    fields = ['NAME', 'GEOID', 'state', 'comparison_phase', 'rate_difference', 'rate_ratio',
              'el_nino_count', 'la_nina_count', 'neutral_count', 'low_count']
    fields += [x for x in ['gi_class', 'gi_q', 'moran_class', 'moran_q'] if x in result]
    folium.GeoJson(result, name='County details', style_function=lambda _: {'fillOpacity':0, 'weight':.4},
                   tooltip=folium.GeoJsonTooltip(fields=fields)).add_to(m)
    palette = {'Hot spot':'#b2182b', 'Cold spot':'#2166ac', 'High-High':'#b2182b',
               'Low-Low':'#2166ac', 'Low-High':'#67a9cf', 'High-Low':'#ef8a62',
               'Island':'#333333', 'Not significant':'#cccccc'}
    for column in ['gi_class', 'moran_class']:
        if column in result:
            folium.GeoJson(result, name=column, show=False,
                style_function=lambda feature, col=column: {'fillColor':palette.get(feature['properties'][col], '#cccccc'),
                    'fillOpacity':.7, 'color':'#555555', 'weight':.4},
                tooltip=folium.GeoJsonTooltip(fields=fields)).add_to(m)
    folium.LayerControl().add_to(m)
    m.fit_bounds([[result.total_bounds[1], result.total_bounds[0]], [result.total_bounds[3], result.total_bounds[2]]])
    m.save(output / 'county_map.html')
    metadata = {'start':start, 'end':end, 'source_coverage':source_meta, 'source':str(source),
        'refresh':refresh, 'boundary_source':str(boundary_path), 'boundary_url':BOUNDARY_URL,
        'comparison_phase':phase, 'hazard':hazard, 'spatial_method':method,
        'method':'Unique county+state-disaster DR/EM designations; incident-onset month; centered RONI thresholds ±0.5; rates per 12 phase months',
        'spatial_details':'Queen neighbors within Region 6; islands unclassified; Gi* selected-phase rates, analytical two-sided p; Local Moran rate differences, doubled permutation p; BH correction separately by test; 999 permutations seed 24601',
        'missing_roni_months':int(tables['county_exposure_months'].enso_phase.isna().sum()),
        'limitations':'Descriptive association, not physical storm frequency or causation. Fixed 2024 boundaries; seasonality unadjusted. County 000/tribal/nonmatching FIPS not allocated. No population normalization. Partial endpoint months use monthly exposure.'}
    (output / 'run_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    log(f'Complete: {len(result)} counties; {len(tables["county_join_audit"])} records in join audit. Map: {output / "county_map.html"}')


def install_county_extension(api):
    tk, ttk, filedialog, messagebox = [api[x] for x in ['tk', 'ttk', 'filedialog', 'messagebox']]
    base = api['App']
    class CountyApp(base):
        def __init__(self):
            super().__init__()
            self.title('ENSO–FEMA | Region 6 County Hotspots')
            self.geometry('1050x880')
            defaults = Path(__file__).parent / 'cached_baseline'
            self.start.set('2001-01-01'); self.end.set('2026-10-07')
            self.output.set(str(Path(__file__).parent / 'county_results'))
            self.source = tk.StringVar(value=str(defaults))
            bundled_boundary = Path(__file__).parent / 'boundaries' / 'cb_2024_us_county_500k.zip'
            self.boundary = tk.StringVar(value=str(bundled_boundary) if bundled_boundary.exists() else '')
            self.phase = tk.StringVar(value='El Nino')
            self.hazard = tk.StringVar(value='All weather')
            self.method = tk.StringVar(value='None')
            self.refresh = tk.BooleanVar(value=False)
            frame = ttk.LabelFrame(self, text='County hotspot options — cached data by default', padding=12)
            frame.pack(side='bottom', fill='x', padx=22, pady=12)
            for label, var, directory in [('Existing analysis folder', self.source, True), ('County boundary file (optional)', self.boundary, False)]:
                row = ttk.Frame(frame); row.pack(fill='x', pady=3)
                ttk.Label(row, text=label, width=30).pack(side='left')
                ttk.Entry(row, textvariable=var).pack(side='left', expand=True, fill='x')
                def browse(v=var, d=directory):
                    path = filedialog.askdirectory() if d else filedialog.askopenfilename()
                    if path: v.set(path)
                ttk.Button(row, text='Browse', command=browse).pack(side='left')
            row = ttk.Frame(frame); row.pack(fill='x', pady=8)
            for label, var, values in [('Compare', self.phase, PHASES[:2]), ('Hazard', self.hazard,
                    ['All weather','Flooding','Tornado','Severe storms','Winter weather','Tropical weather','Coastal weather','Wildfire/fire','Drought','Landslide']),
                    ('Spatial test', self.method, ['None','Gi*','Local Moran','Both'])]:
                ttk.Label(row, text=label).pack(side='left', padx=4)
                ttk.Combobox(row, textvariable=var, values=values, state='readonly', width=18).pack(side='left')
            ttk.Checkbutton(frame, text='Refresh NOAA and FEMA (downloads source data again)', variable=self.refresh).pack(anchor='w')
            ttk.Button(frame, text='Open interactive map', command=self.open_map).pack(anchor='w', pady=4)
            self.run_btn.config(text='Run County Analysis')
        def open_map(self):
            p = Path(self.output.get()) / 'county_map.html'
            if p.exists(): webbrowser.open(p.resolve().as_uri())
            else: messagebox.showinfo('Map', 'Run county analysis first.')
        def start_run(self):
            if self.closing or (self.worker_thread and self.worker_thread.is_alive()): return
            try:
                a, b = api['date'].fromisoformat(self.start.get()), api['date'].fromisoformat(self.end.get())
                if a > b or a.year < 2000: raise ValueError('Use an ordered date range from 2000 onward.')
                if not self.output.get().strip(): raise ValueError('Select an output folder.')
                values = (self.output.get(), self.source.get(), a.isoformat(), b.isoformat(),
                          self.phase.get(), self.hazard.get(), self.method.get(), self.boundary.get(), self.refresh.get())
                if not values[-1]: load_cache(values[1], values[2], values[3])
            except Exception as exc:
                messagebox.showerror('Invalid settings', str(exc)); return
            self.run_btn.config(state='disabled'); self.progress.start(12)
            def work():
                try:
                    run_counties(api, *values, lambda msg:self.q.put(('log', msg)))
                    self.q.put(('done', 'County outputs and interactive map are ready.'))
                except Exception: self.q.put(('error', traceback.format_exc()))
            self.worker_thread = threading.Thread(target=work, daemon=False); self.worker_thread.start()
    api['App'] = CountyApp
