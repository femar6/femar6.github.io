"""ENSO/FEMA Region 6 historical baseline. No ArcPy required."""
import io
import json
import queue
import re
import sqlite3
import threading
import traceback
from contextlib import closing
from datetime import date, datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import pandas as pd
import requests

FEMA_URL = 'https://www.fema.gov/api/open/v2/DisasterDeclarationsSummaries'
RONI_URL = 'https://www.cpc.ncep.noaa.gov/data/indices/RONI.ascii.txt'
STATES = ['AR', 'LA', 'NM', 'OK', 'TX']
WEATHER_TYPES = {'Coastal Storm', 'Dam/Levee Break', 'Drought', 'Fire', 'Flood',
                 'Freezing', 'Hurricane', 'Mud/Landslide', 'Severe Ice Storm',
                 'Severe Storm', 'Snowstorm', 'Tornado', 'Tropical Storm',
                 'Typhoon', 'Other'}
EXCLUDED_TYPES = {'Biological', 'Chemical', 'Civil Unrest', 'Earthquake',
                  'Fishing Losses', 'Human Cause', 'Terrorist', 'Toxic Substances',
                  'Volcano', 'Pandemic'}
SEASON_MID = {'DJF': 1, 'JFM': 2, 'FMA': 3, 'MAM': 4, 'AMJ': 5, 'MJJ': 6,
              'JJA': 7, 'JAS': 8, 'ASO': 9, 'SON': 10, 'OND': 11, 'NDJ': 12}

def excel_safe_dataframe(df):
    """Make an Excel export copy; retain timezone-aware dates in source data.

    Excel cannot store timezone-aware datetimes. Convert them to UTC first,
    then remove timezone information. Handle object columns as well as pandas
    datetime columns, including null values.
    """
    result = df.copy(deep=True)

    def convert_cell(value):
        if isinstance(value, (datetime, pd.Timestamp)):
            timestamp = pd.Timestamp(value)
            if timestamp.tzinfo is not None:
                return timestamp.tz_convert('UTC').tz_localize(None)
        return value

    for column in result.columns:
        values = result[column]
        if isinstance(values.dtype, pd.DatetimeTZDtype):
            result[column] = values.dt.tz_convert('UTC').dt.tz_localize(None)
        elif values.dtype == object:
            result[column] = values.map(convert_cell)
    return result

def fetch_roni(session, log):
    log('Downloading NOAA CPC RONI index...')
    response = session.get(RONI_URL, timeout=90)
    response.raise_for_status()
    content = response.text
    records = []
    for line in content.splitlines():
        p = line.strip().split()
        if not p or p[0].lower() in ('seas', 'season', 'year'):
            continue
        # Official NOAA ASCII: SEAS YR TOTAL ANOM ... RONI (RONI is last numeric column)
        # Also supports alternative YEAR SEASON ... and YEAR + 12 seasonal values.
        try:
            if p[0].upper() in SEASON_MID and len(p) >= 3 and re.fullmatch(r'\d{4}', p[1]):
                season, year, val = p[0].upper(), int(p[1]), float(p[-1])
                records.append((year, SEASON_MID[season], val))
            elif re.fullmatch(r'\d{4}', p[0]) and len(p) >= 3 and p[1].upper() in SEASON_MID:
                year, season, val = int(p[0]), p[1].upper(), float(p[-1])
                records.append((year, SEASON_MID[season], val))
            elif re.fullmatch(r'\d{4}', p[0]) and len(p) == 13:
                for month, v in enumerate(p[1:], 1):
                    records.append((int(p[0]), month, float(v)))
        except ValueError:
            continue
    if len(records) < 100:
        raise ValueError('Unable to parse NOAA RONI format; inspect raw/roni.ascii.txt before proceeding.')
    df = pd.DataFrame(records, columns=['year', 'month', 'roni']).drop_duplicates(['year', 'month'], keep='last')
    df = df[(df.roni > -10) & (df.roni < 10)].copy()
    if len(df) < 100:
        raise ValueError('RONI parsed values failed plausibility checks')
    df['year_month'] = pd.to_datetime(dict(year=df.year, month=df.month, day=1)).dt.strftime('%Y-%m')
    df['enso_phase'] = df.roni.map(lambda v: 'El Nino' if v >= 0.5 else ('La Nina' if v <= -0.5 else 'Neutral'))
    def strength(v):
        a = abs(v)
        if a < 0.5: return 'Neutral'
        if a < 1: return 'Weak'
        if a < 1.5: return 'Moderate'
        if a < 2: return 'Strong'
        return 'Very strong'
    df['strength'] = df.roni.map(strength)
    return content, df.sort_values('year_month')

def fetch_fema(session, start, end, log):
    log('Downloading OpenFEMA disaster designation records...')
    rows = []
    page_size = 1000
    for state in STATES:
        skip = 0
        while True:
            filt = (f"state eq '{state}' and declarationDate ge '{start}T00:00:00.000Z' "
                    f"and declarationDate le '{end}T23:59:59.999Z' "
                    "and (declarationType eq 'DR' or declarationType eq 'EM')")
            params = {'$filter': filt, '$top': page_size, '$skip': skip, '$orderby': 'disasterNumber asc'}
            response = session.get(FEMA_URL, params=params, timeout=120)
            response.raise_for_status()
            payload = response.json()
            batch = payload.get('DisasterDeclarationsSummaries')
            if batch is None:
                raise ValueError('Unexpected FEMA response structure')
            rows.extend(batch)
            skip += len(batch)
            log(f'{state}: {skip:,} designation records')
            if len(batch) < page_size:
                break
    if not rows:
        raise ValueError('FEMA returned no records. Check dates and connectivity.')
    return pd.DataFrame(rows)

def hazard_group(t):
    return {'Flood': 'Flooding', 'Dam/Levee Break': 'Flooding',
            'Tornado': 'Tornado', 'Severe Storm': 'Severe storms',
            'Snowstorm': 'Winter weather', 'Severe Ice Storm': 'Winter weather',
            'Freezing': 'Winter weather', 'Hurricane': 'Tropical weather',
            'Tropical Storm': 'Tropical weather', 'Typhoon': 'Tropical weather',
            'Coastal Storm': 'Coastal weather', 'Fire': 'Wildfire/fire',
            'Drought': 'Drought', 'Mud/Landslide': 'Landslide'}.get(t, 'Other / review')

def analyze(fema, roni, start, end, log):
    f = fema.copy()
    for c in ['declarationDate', 'incidentBeginDate', 'incidentEndDate']:
        if c not in f.columns: f[c] = None
        f[c] = pd.to_datetime(f[c], errors='coerce', utc=True)
    f['incident_month'] = f.incidentBeginDate.dt.strftime('%Y-%m')
    f['incident_type'] = f.get('incidentType', pd.Series('', index=f.index)).fillna('').astype(str)
    f['hazard_group'] = f.incident_type.map(hazard_group)
    f['weather_included'] = f.incident_type.isin(WEATHER_TYPES) & ~f.incident_type.isin(EXCLUDED_TYPES)
    # 'Other' is ambiguous and excluded pending human review.
    f.loc[f.incident_type.eq('Other'), 'weather_included'] = False
    f['disaster_key'] = f['state'].astype(str) + '-' + f['disasterNumber'].astype(str)
    f = f.merge(roni[['year_month', 'roni', 'enso_phase', 'strength']],
                how='left', left_on='incident_month', right_on='year_month', validate='many_to_one')
    # Keep incidents whose onset is within requested window, even if declaration occurred in it later.
    start_month = start[:7]
    end_month = end[:7]
    f = f[(f.incident_month >= start_month) & (f.incident_month <= end_month)].copy()
    included = f[f.weather_included & f.enso_phase.notna()].copy()
    events = included.sort_values('declarationDate').drop_duplicates('disaster_key').copy()
    # Full state-month panel: zero months are essential to unbiased rates.
    months = pd.period_range(start_month, end_month, freq='M').astype(str)
    panel = pd.MultiIndex.from_product([STATES, months], names=['state', 'year_month']).to_frame(index=False)
    panel = panel.merge(roni[['year_month', 'roni', 'enso_phase', 'strength']], on='year_month', how='left', validate='many_to_one')
    counts = events.groupby(['state', 'incident_month']).size().rename('unique_declarations').reset_index()
    counts = counts.rename(columns={'incident_month': 'year_month'})
    panel = panel.merge(counts, on=['state', 'year_month'], how='left')
    panel['unique_declarations'] = panel.unique_declarations.fillna(0).astype(int)
    panel['year'] = panel.year_month.str[:4].astype(int)
    panel['month'] = panel.year_month.str[5:7].astype(int)
    summary = panel.dropna(subset=['enso_phase']).groupby(['state', 'enso_phase'], as_index=False).agg(
        months=('year_month', 'size'), unique_declarations=('unique_declarations', 'sum'))
    summary['declarations_per_12_months'] = (12 * summary.unique_declarations / summary.months).round(3)
    hazard = events.groupby(['state', 'enso_phase', 'hazard_group'], as_index=False).agg(
        unique_declarations=('disaster_key', 'nunique'))
    qa = pd.DataFrame([{'metric': 'fema_designation_records_downloaded', 'value': len(fema)},
                       {'metric': 'fema_records_incident_onset_in_window', 'value': len(f)},
                       {'metric': 'weather_designation_records_matched_to_roni', 'value': len(included)},
                       {'metric': 'unique_weather_declarations', 'value': len(events)},
                       {'metric': 'incident_month_missing', 'value': int(f.incident_month.isna().sum())},
                       {'metric': 'roni_missing_for_incident', 'value': int(f.enso_phase.isna().sum())},
                       {'metric': 'unknown_incident_types', 'value': ', '.join(sorted(set(f.incident_type) - WEATHER_TYPES - EXCLUDED_TYPES))}])
    log(f'Found {len(events):,} unique matched weather-related declarations')
    return f, events, panel, summary, hazard, qa

def run_pipeline(output, start, end, log):
    output = Path(output)
    raw = output / 'raw'
    raw.mkdir(parents=True, exist_ok=True)
    with requests.Session() as session:
        session.headers.update({'User-Agent': 'ENSO-FEMA-Region6-Research/1.0', 'Accept': 'application/json,text/plain,*/*'})
        roni_text, roni = fetch_roni(session, log)
        (raw / 'RONI.ascii.txt').write_text(roni_text, encoding='utf-8')
        fema = fetch_fema(session, start, end, log)
    fema.to_json(raw / 'fema_designations.json', orient='records', date_format='iso', indent=2)
    normalized, events, panel, summary, hazard, qa = analyze(fema, roni, start, end, log)
    tables = {'roni_monthly': roni, 'fema_designations_joined': normalized,
              'unique_declarations': events, 'state_month_panel': panel,
              'phase_summary': summary, 'hazard_summary': hazard, 'quality_checks': qa}
    log('Writing CSV, Excel and SQLite outputs...')
    for name, df in tables.items():
        df.to_csv(output / (name + '.csv'), index=False)
    with pd.ExcelWriter(output / 'ENSO_FEMA_Region6.xlsx', engine='openpyxl') as writer:
        for name, df in tables.items():
            excel_safe_dataframe(df).to_excel(writer, sheet_name=name[:31], index=False)
    with closing(sqlite3.connect(output / 'ENSO_FEMA_Region6.sqlite')) as db:
        for name, df in tables.items():
            df.to_sql(name, db, if_exists='replace', index=False)
        db.commit()
    (output / 'run_metadata.json').write_text(json.dumps({
        'start': start, 'end': end, 'states': STATES,
        'fema_url': FEMA_URL, 'roni_url': RONI_URL,
        'method': 'Incident-onset month matched to centered seasonal RONI; DR/EM unique by state+disasterNumber; Other excluded',
        'excel_datetime_convention': 'UTC with timezone removed in Excel export copies only; CSV and SQLite use original data',
        'warning': 'RONI monthly thresholds are not equivalent to NOAA confirmed 5-season ENSO episodes.'
    }, indent=2), encoding='utf-8')
    log('Complete. Outputs saved in ' + str(output))

def pipeline_worker(out, start, end, messages):
    """Background work receives plain values and a queue, never Tk objects."""
    try:
        run_pipeline(out, start, end, lambda message: messages.put(('log', message)))
        messages.put(('done', 'Analysis completed successfully.'))
    except Exception:
        messages.put(('error', traceback.format_exc()))


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('ENSO–FEMA | Region 6 Historical Analyzer')
        self.geometry('850x620')
        self.minsize(720, 500)
        self.configure(bg='#f3f6fa')
        self.q = queue.Queue()
        self.worker_thread = None
        self.closing = False
        self.closed = False
        self.poll_id = None
        self.protocol('WM_DELETE_WINDOW', self.close)
        frame = ttk.Frame(self, padding=22)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='ENSO × FEMA  |  Region 6', font=('Segoe UI', 19, 'bold')).pack(anchor='w')
        ttk.Label(frame, text='Historical DR / EM baseline • AR, LA, NM, OK, TX • NOAA RONI', font=('Segoe UI', 10)).pack(anchor='w', pady=(3, 18))
        settings = ttk.LabelFrame(frame, text='Analysis settings', padding=12)
        settings.pack(fill='x')
        self.start = tk.StringVar(value='2000-01-01')
        self.end = tk.StringVar(value=date.today().isoformat())
        self.output = tk.StringVar(value=str(Path.home() / 'ENSO_FEMA_Region6'))
        dates = ttk.Frame(settings)
        dates.pack(fill='x', pady=5)
        ttk.Label(dates, text='Start date').pack(side='left')
        ttk.Entry(dates, textvariable=self.start, width=14).pack(side='left', padx=(8, 25))
        ttk.Label(dates, text='End date').pack(side='left')
        ttk.Entry(dates, textvariable=self.end, width=14).pack(side='left', padx=8)
        folder = ttk.Frame(settings)
        folder.pack(fill='x', pady=8)
        ttk.Label(folder, text='Output folder').pack(side='left')
        ttk.Entry(folder, textvariable=self.output).pack(side='left', fill='x', expand=True, padx=10)
        ttk.Button(folder, text='Browse', command=self.browse).pack(side='left')
        self.run_btn = ttk.Button(frame, text='Download & Run Analysis', command=self.start_run)
        self.run_btn.pack(anchor='w', pady=17)
        self.progress = ttk.Progressbar(frame, mode='indeterminate')
        self.progress.pack(fill='x', pady=(0, 10))
        ttk.Label(frame, text='Processing log', font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        self.log_widget = tk.Text(frame, height=16, bg='#172333', fg='#e3edf7', font=('Consolas', 10), wrap='word')
        self.log_widget.pack(fill='both', expand=True, pady=(5, 8))
        ttk.Label(frame, text='Descriptive county associations; review join audits, exposure coverage, and low-count flags.',
                  foreground='#576575').pack(anchor='w')
        self.poll_id = self.after(150, self.poll)
    def browse(self):
        path = filedialog.askdirectory()
        if path: self.output.set(path)
    def log(self, message): self.q.put(('log', message))
    def start_run(self):
        if self.closing or (self.worker_thread and self.worker_thread.is_alive()):
            return
        try:
            a, b = date.fromisoformat(self.start.get()), date.fromisoformat(self.end.get())
            if a > b: raise ValueError('Start date must not exceed end date')
            if a.year < 2000: raise ValueError('Select 2000 or later')
            if not self.output.get().strip(): raise ValueError('Select an output folder')
        except ValueError as exc:
            messagebox.showerror('Invalid settings', str(exc))
            return
        self.run_btn.config(state='disabled')
        self.progress.start(12)
        self.worker_thread = threading.Thread(
            target=pipeline_worker,
            args=(self.output.get(), self.start.get(), self.end.get(), self.q),
            daemon=False)
        self.worker_thread.start()
    def close(self):
        if self.closed:
            return
        self.closing = True
        self.run_btn.config(state='disabled')
        if self.worker_thread and self.worker_thread.is_alive():
            self.title('ENSO–FEMA | Finishing current work before closing…')
            self.log('Closing after the current download/export finishes. Please wait.')
            return
        self.destroy()

    def destroy(self):
        # All shutdown and Tk object cleanup must run on the main thread.
        if self.closed:
            return
        if self.worker_thread and self.worker_thread.is_alive():
            self.close()
            return
        self.closed = True
        if self.poll_id is not None:
            self.after_cancel(self.poll_id)
            self.poll_id = None
        self.progress.stop()
        super().destroy()

    def poll(self):
        self.poll_id = None
        if self.closed:
            return
        try:
            while True:
                kind, msg = self.q.get_nowait()
                if kind == 'log':
                    self.log_widget.insert('end', msg + '\n')
                    self.log_widget.see('end')
                else:
                    self.progress.stop()
                    self.run_btn.config(state='disabled' if self.closing else 'normal')
                    if kind == 'error':
                        self.log_widget.insert('end', msg + '\n')
                        self.log_widget.see('end')
                        if not self.closing:
                            messagebox.showerror('Analysis failed', msg.splitlines()[-1])
                    elif not self.closing:
                        messagebox.showinfo('Complete', msg)
        except queue.Empty:
            pass
        if self.closing and not (self.worker_thread and self.worker_thread.is_alive()):
            self.destroy()
            return
        if not self.closed:
            self.poll_id = self.after(150, self.poll)

from county_hotspots import install_county_extension
install_county_extension(globals())

if __name__ == '__main__':
    app = App()
    app.mainloop()
