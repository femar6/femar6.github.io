# ENSO–FEMA Region 6: county hotspot version

Requires Python 3.12 or 3.13 with Tkinter (included in standard Windows Python).
Extract the entire package together. Open a terminal in its folder and run:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe enso_fema_gui.py
```

The original application is preserved in `enso_fema_gui.py`; `county_hotspots.py` extends its GUI and adds county processing. Keep both files together. Existing NOAA RONI/FEMA download routines, state tables, CSV/Excel/SQLite exports, UTC Excel export fix, and background-thread shutdown behavior are retained.

## First run: no source re-download needed

The defaults use the included `cached_baseline` folder, recovered from the prior completed FEMA package, covering **2001-01-01 through 2026-10-07**. It contains the original SQLite database, raw NOAA/FEMA downloads, and coverage metadata. The included Census boundary ZIP is selected automatically. Click **Run County Analysis**, then **Open interactive map**. Default output goes to `county_results` beside the scripts; select a separate output folder to preserve prior results.

To reuse another run, select its existing analysis folder containing `ENSO_FEMA_Region6.sqlite` and `run_metadata.json`. Raw FEMA JSON is preferred; the joined SQLite table is supported as fallback. A CSV cache is also supported with `roni_monthly.csv` and raw JSON or `fema_designations_joined.csv`. Coverage is checked before running. An NWS-only SQLite database cannot substitute for the FEMA database.

Leave **Refresh NOAA and FEMA** unchecked to reuse data. Check it only when you need newer dates or a broader period. Refresh uses the original DR/EM declaration-date download filter; incidents declared outside that window are not recovered, so late-declaration edge effects remain. If cache coverage is insufficient, the app asks you to narrow dates or refresh instead of downloading silently.

## County analysis

Choose El Nino or La Nina versus Neutral, a hazard group, and optional Gi*, Local Moran, or Both. County state/county FIPS are normalized to five digits and matched to Census GEOID; county 000, invalid FIPS, tribal/nonmatching codes are recorded in the join audit and are not spread across counties. Each county/disaster is counted once, regardless of duplicate program records.

Rates are unique county disaster designations per 12 months in each phase. All boundary counties are included, including counties with zero events. Exposure includes all available RONI months in the requested range, including zero-event months; missing RONI months are excluded and reported. RONI thresholds are ±0.5 applied to the centered seasonal value assigned to each month, not NOAA confirmed five-season episodes. Partial endpoint months count as monthly exposure, matching the existing baseline convention.

The difference is selected ENSO rate minus Neutral rate. The ratio is undefined (blank/gray) when Neutral rate is zero; it is never replaced with an arbitrary pseudocount. `low_count` flags either comparison count below five.

Gi* examines **selected-phase rates**, with binary Queen adjacency and self included. It uses analytical two-sided normal p-values. Local Moran examines **ENSO-minus-Neutral rate differences**, with row-standardized Queen adjacency, 999 permutations, and seed 24601. Its permutation tail probability is doubled and capped at one. Both tests apply Benjamini–Hochberg correction across non-island counties separately, labeling q ≤ 0.05. Islands remain unclassified. Regional borders truncate neighborhoods; no neighbors outside Region 6 are inferred.

These are descriptive associations in FEMA declarations, not storm counts, loss estimates, population-normalized risk, or causal ENSO effects. Seasonality, reporting changes, and sparse county counts can influence patterns. Fixed 2024 county boundaries are used throughout the historical window.

## Outputs

- `county_hotspots.csv`, `.geojson`, `.gpkg`: all counties, phase counts/exposure/rates, differences/ratios, low-count flag, optional spatial statistics.
- `county_map.html`: browser map with switchable numeric layers and county details. Internet access is needed for Leaflet assets and background tiles.
- `county_designations.csv`: deduplicated eligible county declarations.
- `county_join_audit.csv`: records not matched to county boundaries, with reasons.
- `county_exposure_months.csv`: monthly phase/exposure audit.
- `ENSO_FEMA_Region6.xlsx` and `.sqlite`: existing baseline tables plus county tables.
- `run_metadata.json`: source, dates, options, methods, and limitations.

Existing output files are replaced on another run in the same output folder. The input SQLite database is opened read-only; use a distinct output folder to keep it intact.

Boundary source: https://www2.census.gov/geo/tiger/GENZ2024/shp/cb_2024_us_county_500k.zip
Methods: https://pysal.org/esda/stable/generated/esda.G_Local.html and https://pysal.org/esda/stable/user-guide/local_spatial_autocorrelation.html
