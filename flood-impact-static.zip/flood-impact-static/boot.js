(async function(){
 const status=document.getElementById('analysisStatus');
 async function load(url){return new Promise((resolve,reject)=>{const tag=document.createElement('script');tag.src=url;tag.onload=resolve;tag.onerror=()=>reject(Error('Could not load '+url));document.head.append(tag);});}
 async function ensure(name,ready,urls){if(ready())return;for(const url of urls){status.textContent='Loading '+name+'…';try{await load(url);if(ready())return;}catch{}}throw Error(name+' could not load. Check internet access to unpkg.com and cdn.jsdelivr.net.');}
 try{
  await ensure('Leaflet',()=>!!window.L,['https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js','https://unpkg.com/leaflet@1.9.4/dist/leaflet.js']);
  await ensure('Drawing controls',()=>!!window.L?.Control?.Draw,['https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.js','https://cdn.jsdelivr.net/npm/leaflet-draw@1.0.4/dist/leaflet.draw.js']);
  await ensure('Turf',()=>!!window.turf,['https://unpkg.com/@turf/turf@7.2.0/turf.min.js','https://cdn.jsdelivr.net/npm/@turf/turf@7.2.0/turf.min.js']);
  for(const file of ['./core.js','./services.js','./analysis.js','./app.js'])await load(file);
 }catch(e){status.textContent='Startup failed: '+e.message;const message=document.createElement('div');message.style.cssText='position:absolute;z-index:1800;top:80px;left:20px;right:20px;padding:20px;background:white;border:2px solid #df737b;border-radius:8px;font:14px/1.6 Arial;color:#173f5f';message.textContent='Unable to start the map. '+e.message;document.getElementById('map').append(message);console.error(e);}
})();
