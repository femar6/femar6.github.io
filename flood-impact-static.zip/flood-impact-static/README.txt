FLOOD IMPACT WORKBENCH — BROWSER EDITION

NO NODE.JS, NPM, BUILD STEP OR APPLICATION SERVER.

1. Extract the complete ZIP into one folder.
2. Open index.html in a current Chrome, Edge, Firefox or Brave browser.
   Alternatively, copy the folder to any normal static web host and open index.html.
3. Keep the .js and .css files beside index.html. Internet access is required for
   live data, basemap tiles and the pinned browser libraries from public CDNs.

This edition uses ordinary classic JavaScript files (no JavaScript module imports),
so it does not require a local module server. It does not fetch /api/catalog,
/api/query or /tiles from a local server. All requests go directly to the selected
ArcGIS service. The API-style operation names inside the JavaScript are internal
function dispatch only; they are not local network endpoints.

Choose an analysis mode:
- FLOOD EXPOSURE: separate NFHL / NBM / current / uploaded / custom polygon exposure
  counts within the AOI. Residential, commercial, other/unknown and facility types.
- AOI / WATCH / WARNING ONLY: inventory of recorded structures and facilities inside
  the chosen boundary, without querying NFHL or inundation. Not flood exposure.

Draw or upload an AOI, select a warning polygon, or use the map view. Uploaded
GeoJSON must be WGS84 Polygon/MultiPolygon; declare AOI or inundation, supply its
written title and details. First uploaded inundation can supply its own boundary.
Examples are SYNTHETIC test geometry, not actual flooding.

Optional custom ArcGIS source: paste an HTTPS FeatureServer or MapServer URL;
inspect and select a child layer if needed. Choose AOI, inundation/hazard,
infrastructure or reference context. Polygon hazard geometry is required for
exposure. Enter title, source/valid-time details, and confirm footprint meaning.
Public services must allow browser cross-origin access (CORS). This static app
cannot override CORS restrictions, sign into protected services or proxy blocked
sources. It will show an unavailable source, not a zero count. Some services reject
requests from a double-clicked file (the browser sends a null origin); hosting the
same files on a normal HTTPS static site may resolve that. Do not disable browser
security. No custom-host environment configuration is needed in this edition.

Queries run ON THE ARCGIS SERVER using the AOI envelope. The browser obtains all
matching object IDs, retrieves features in bounded batches, recursively retries
truncated batches and reconciles IDs. It then performs exact AOI / flood clipping
and footprint intersection locally using Turf. Limit: 60,000 candidate features
per source and AOI area 10,000 km2. Reduce the AOI if a limit is reached.

Building footprint intersections include boundary touches and are estimated
record counts, not households, people, damage or depth. OCC_CLS drives occupancy
classification; missing/other values remain Other / unknown. Layer counts overlap.
The combined structure total is deduplicated only when all structure/hazard results
are complete. Facility inventories remain separate and can contain the same site.

PDF MAP captures the current map view with only displayed layers, plus the AOI
boundary annotation, separate structure counts and source/details appendix. PDF
REPORT adds occupancy and facility results and provenance. Counts cover the full
AOI even when the displayed map is smaller. Edit report title/details and layer
title/details before exporting. Basemap images require cross-origin-readable tiles
for PDF capture; turn off the basemap if tiles fail or cannot be captured. Exports
use browser libraries; PDF rendering still needs local visual verification.

EXPORT DATA downloads full analysis JSON, record CSV and GeoJSON. Your browser
may ask to allow multiple downloads. Session data stays in memory; export before
reloading. Custom sources and uploads are not persisted automatically.

DATA MEANING:
NFHL is regulatory 1% annual-chance Special Flood Hazard Area including floodways;
not an event forecast. NBM is modeled five-day inundation, not precipitation.
Current NWM is modeled analysis inundation, not direct observation. RFC is a separate
five-day forecast. GFS is global-model-forced CONUS river context, not worldwide
inundation and not an exposure footprint. Worldwide polygon data can be uploaded,
but USA Structures / configured facility inventories do not establish global
exposure coverage. Warning polygons define AOIs, not inundated areas.

Actual runtime fields, capabilities, source URLs, retrieval times and returned
source reference/update time fields are retained in provenance and analysis JSON.
Retrieval time is not forecast valid time. Unknown/failed sources are not zero risk.
Live service availability and browser/PDF rendering could not be verified in the
build environment. See VALIDATION.txt for the checks actually performed.

Files: index.html, style.css, boot.js, core.js, services.js, analysis.js, app.js.
No installation is required. Public CDN versions: Leaflet 1.9.4, Leaflet.draw 1.0.4,
Turf 7.2.0, html2canvas 1.4.1, jsPDF 2.5.2; upstream licenses/terms apply.

Design adapted from the supplied Flood v3 NFIP map and rrcc workflow; original
reference files were not modified. This is not an official FEMA-branded product.
