(function(){
"use strict";
function bbox(geo){
 let b=[Infinity,Infinity,-Infinity,-Infinity],n=0;
 function coords(c){if(Array.isArray(c)&&typeof c[0]==='number'){const [x,y]=c;if(!Number.isFinite(x)||!Number.isFinite(y)||x< -180||x>180||y< -90||y>90)throw Error('Expected WGS84 longitude/latitude');b=[Math.min(b[0],x),Math.min(b[1],y),Math.max(b[2],x),Math.max(b[3],y)];n++;}else if(Array.isArray(c))c.forEach(coords);else throw Error('Invalid coordinates');}
 function visit(g){if(!g)throw Error('Missing geometry');if(g.type==='FeatureCollection')g.features.forEach(visit);else if(g.type==='Feature')visit(g.geometry);else if(['Polygon','MultiPolygon'].includes(g.type))coords(g.coordinates);else throw Error('AOI must contain polygons');}visit(geo);if(!n)throw Error('Empty geometry');if(b[2]-b[0]>180)throw Error('Split antimeridian AOIs');return b;
}
function classify(v){const s=String(v??'').trim().toUpperCase();if(/^RES($|\d)|^RESIDENTIAL/.test(s))return 'Residential';if(/^COM($|\d)|^COMMERCIAL/.test(s))return 'Commercial';return 'Other / unknown';}
async function completeQuery(query,metadata,base,max=60000){
 const r=await query({...base,returnIdsOnly:true,returnGeometry:false});
 if(r.exceededTransferLimit||!('objectIds' in r))throw Error('No complete object-ID list');
 const ids=[...new Set(r.objectIds||[])];if(ids.length>max)throw Error(`Area has ${ids.length} features, above the ${max} safety limit. Use a smaller AOI.`);
 const oid=metadata.objectIdField||metadata.fields.find(f=>f.type==='esriFieldTypeOID')?.name;if(!oid)throw Error('Object-ID field unavailable');
 const features=[],size=Math.min(500,metadata.maxRecordCount||500);
 async function batch(part){const d=await query({objectIds:part.join(','),outFields:'*',returnGeometry:true,outSR:4326,f:'geojson',returnZ:false,returnM:false});if(d.exceededTransferLimit||d.properties?.exceededTransferLimit||d.features?.length!==part.length){if(part.length<=1)throw Error('Incomplete geometry response; analysis stopped');const m=Math.ceil(part.length/2);await batch(part.slice(0,m));await batch(part.slice(m));return;}features.push(...d.features);}
 for(let i=0;i<ids.length;i+=size)await batch(ids.slice(i,i+size));
 const seen=new Set();for(const f of features){const id=f.id??f.properties?.[oid];if(id==null||seen.has(id))throw Error('Missing or duplicate object IDs');seen.add(id);if(!f.geometry)throw Error('Null geometry');}
 if(seen.size!==ids.length||ids.some(id=>!seen.has(id)))throw Error('Feature ID reconciliation failed');
 return {type:'FeatureCollection',features,queryCount:ids.length,objectIdField:oid};
}

window.FloodCore={bbox,classify,completeQuery};
})();
