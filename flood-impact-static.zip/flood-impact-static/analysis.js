(function(){
"use strict";
const {bbox,classify}=window.FloodCore;
const fc=features=>({type:'FeatureCollection',features});
function polygonInput(g){
 const features=g.type==='FeatureCollection'?g.features:g.type==='Feature'?[g]:[{type:'Feature',properties:{},geometry:g}];
 if(!features.length||features.length>5000)throw Error('Upload must contain 1–5,000 polygon features');
 bbox(fc(features));let vertices=0;
 for(const f of features){if(!['Polygon','MultiPolygon'].includes(f.geometry?.type))throw Error('Only Polygon / MultiPolygon GeoJSON is accepted');if(!turf.booleanValid(f)||turf.kinks(f).features.length)throw Error('Invalid polygon geometry. Repair self-intersections, open rings or holes before uploading.');turf.coordEach(f,()=>vertices++);}
 if(vertices>150000)throw Error('Geometry exceeds 150,000 vertices. Simplify before uploading.');
 return fc(features.map(f=>({...f,properties:f.properties||{}})));
}
function mergePolygons(data){const clean=polygonInput(data);return clean.features.length===1?clean.features[0]:turf.union(clean);}
function clippedFootprints(data,area){const out=[];for(const f of data.features){if(!['Polygon','MultiPolygon'].includes(f.geometry?.type))throw Error('Exposure source contains non-polygon geometry');if(!turf.booleanValid(f))throw Error('Invalid hazard polygon in service response');if(turf.booleanIntersects(f,area)){const cut=turf.intersect(fc([f,area]));if(cut)out.push({...cut,properties:f.properties});}}return fc(out);}
function filterArea(data,area){return {...data,features:data.features.filter(f=>turf.booleanIntersects(f,area))};}
// A bounded grid keeps footprint-intersection tests local; every candidate is still tested exactly.
function spatialIndex(polygons){const boxes=polygons.map(f=>turf.bbox(f));const all=boxes.reduce((a,b)=>[Math.min(a[0],b[0]),Math.min(a[1],b[1]),Math.max(a[2],b[2]),Math.max(a[3],b[3])],[Infinity,Infinity,-Infinity,-Infinity]);const cells=new Map(),n=48,dx=Math.max((all[2]-all[0])/n,1e-8),dy=Math.max((all[3]-all[1])/n,1e-8);const range=b=>[Math.max(0,Math.floor((b[0]-all[0])/dx)),Math.max(0,Math.floor((b[1]-all[1])/dy)),Math.min(n,Math.floor((b[2]-all[0])/dx)),Math.min(n,Math.floor((b[3]-all[1])/dy))];boxes.forEach((b,i)=>{const r=range(b);for(let x=r[0];x<=r[2];x++)for(let y=r[1];y<=r[3];y++){const k=x+','+y;if(!cells.has(k))cells.set(k,[]);cells.get(k).push(i);}});return f=>{if(!polygons.length)return false;const b=turf.bbox(f),r=range(b),ids=new Set();for(let x=r[0];x<=r[2];x++)for(let y=r[1];y<=r[3];y++)for(const i of cells.get(x+','+y)||[])ids.add(i);return [...ids].some(i=>{const a=boxes[i];return b[0]<=a[2]&&b[2]>=a[0]&&b[1]<=a[3]&&b[3]>=a[1]&&turf.booleanIntersects(f,polygons[i]);});};}
async function exposure(footprints,structures,infrastructure,progress=()=>{}){const hits=spatialIndex(footprints.features),counts={'Residential':0,'Commercial':0,'Other / unknown':0},features=[],occupancy={};
 if(structures){for(let i=0;i<structures.features.length;i++){const f=structures.features[i];if(hits(f)){const raw=f.properties.OCC_CLS,category=classify(raw);counts[category]++;occupancy[raw||'Unknown']=(occupancy[raw||'Unknown']||0)+1;features.push({...f,properties:{...f.properties,exposure_category:category}});}if(i%400===0){progress(i,structures.features.length);await new Promise(r=>setTimeout(r,0));}}}
 const facilities={};for(const [key,d] of Object.entries(infrastructure)){facilities[key]=d.error?{error:d.error,title:d.title}:{title:d.title,features:d.features.filter(hits),source:d.source};}
 return {counts:structures?counts:null,occupancy,structures:fc(features),structureError:structures?null:'USA Structures unavailable',facilities,footprintCount:footprints.features.length};}

window.FloodAnalysis={fc,polygonInput,mergePolygons,clippedFootprints,filterArea,exposure,spatialIndex};
})();
